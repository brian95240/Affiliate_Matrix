"""
Dorking strategies package for the Affiliate Matrix Google Dorking implementation.
This package contains specialized modules for different dorking strategies.
"""
